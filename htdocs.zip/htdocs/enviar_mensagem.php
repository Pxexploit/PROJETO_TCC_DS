<?php
session_start();

if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['usuario_tipo'], ['cliente', 'vendedor'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_login";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

header('Content-Type: application/json');

$conversa_id = intval($_POST['conversa_id'] ?? 0);
$mensagem = trim($_POST['mensagem'] ?? '');
$usuario_id = $_SESSION['usuario_id'];
$usuario_tipo = $_SESSION['usuario_tipo'];

if ($conversa_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Conversa inválida']);
    exit();
}

// Verificar se a conversa existe e o usuário tem acesso
$sql_verificar = "SELECT * FROM conversas WHERE id_conversa = ? AND (id_cliente = ? OR id_vendedor = ?)";
$stmt_verificar = $conn->prepare($sql_verificar);
$stmt_verificar->bind_param("iii", $conversa_id, $usuario_id, $usuario_id);
$stmt_verificar->execute();
$conversa = $stmt_verificar->get_result()->fetch_assoc();

if (!$conversa) {
    echo json_encode(['success' => false, 'message' => 'Conversa não encontrada']);
    exit();
}

$tipo_mensagem = 'texto';
$arquivo_nome = null;
$arquivo_caminho = null;
$arquivo_tamanho = null;

// Processar upload de arquivo se houver
if (isset($_FILES['arquivo']) && $_FILES['arquivo']['error'] === UPLOAD_ERR_OK) {
    $arquivo = $_FILES['arquivo'];
    $arquivo_nome = $arquivo['name'];
    $arquivo_tamanho = $arquivo['size'];
    $arquivo_tipo = $arquivo['type'];
    
    // Validar tamanho (máximo 10MB)
    if ($arquivo_tamanho > 10 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'Arquivo muito grande. Máximo 10MB.']);
        exit();
    }
    
    // Validar tipo de arquivo
    $tipos_permitidos = [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp',
        'video/mp4', 'video/avi', 'video/mov',
        'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    if (!in_array($arquivo_tipo, $tipos_permitidos)) {
        echo json_encode(['success' => false, 'message' => 'Tipo de arquivo não permitido.']);
        exit();
    }
    
    // Determinar tipo de mensagem
    if (strpos($arquivo_tipo, 'image/') === 0) {
        $tipo_mensagem = 'imagem';
    } elseif (strpos($arquivo_tipo, 'video/') === 0) {
        $tipo_mensagem = 'video';
    } else {
        $tipo_mensagem = 'arquivo';
    }
    
    // Criar diretório se não existir
    $upload_dir = 'uploads/chat/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Gerar nome único para o arquivo
    $extensao = pathinfo($arquivo_nome, PATHINFO_EXTENSION);
    $nome_unico = uniqid() . '_' . time() . '.' . $extensao;
    $arquivo_caminho = $upload_dir . $nome_unico;
    
    // Mover arquivo
    if (!move_uploaded_file($arquivo['tmp_name'], $arquivo_caminho)) {
        echo json_encode(['success' => false, 'message' => 'Erro ao fazer upload do arquivo.']);
        exit();
    }
}

// Se não há mensagem de texto nem arquivo
if (empty($mensagem) && empty($arquivo_nome)) {
    echo json_encode(['success' => false, 'message' => 'Mensagem não pode estar vazia.']);
    exit();
}

// Inserir mensagem no banco
$sql_inserir = "INSERT INTO mensagens (id_conversa, id_remetente, tipo_remetente, mensagem, tipo_mensagem, arquivo_nome, arquivo_caminho, arquivo_tamanho) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt_inserir = $conn->prepare($sql_inserir);
$stmt_inserir->bind_param("iisssssi", $conversa_id, $usuario_id, $usuario_tipo, $mensagem, $tipo_mensagem, $arquivo_nome, $arquivo_caminho, $arquivo_tamanho);

if ($stmt_inserir->execute()) {
    // Atualizar timestamp da última mensagem na conversa
    $sql_atualizar = "UPDATE conversas SET ultima_mensagem = NOW() WHERE id_conversa = ?";
    $stmt_atualizar = $conn->prepare($sql_atualizar);
    $stmt_atualizar->bind_param("i", $conversa_id);
    $stmt_atualizar->execute();
    
    echo json_encode(['success' => true, 'message' => 'Mensagem enviada com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao enviar mensagem: ' . $conn->error]);
}

$conn->close();
?>
