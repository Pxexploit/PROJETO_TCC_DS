<?php
session_start();

if (!isset($_SESSION['id_cliente']) || $_SESSION['tipo'] !== 'admin') {
    echo "<div style='color: red;'>Acesso negado. Você não tem permissão para acessar esta página.</div>";
    exit();
}

include('conexao.php');
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Painel Administrativo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            background-color: #151718;
            color: #e0e0e0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        nav {
            background-color: #1f1f1f;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
        }

        nav a {
            color: #fff;
            margin: 0 10px;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 20px;
        }

        h2 {
            color: #2596be;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            background-color: #1e1e1e;
            table-layout: fixed;
        }

        th,
        td {
            padding: 10px 15px;
            border: 1px solid #2596be;
            text-align: left;
            vertical-align: middle;
            word-wrap: break-word;
            overflow-wrap: break-word;
            white-space: normal;
            font-size: 14px;
        }

        th {
            background-color: #333;
            font-weight: bold;
            text-align: left;
            color: #e0e0e0;
        }

        /* Evita quebra feia de botões */
        td a.btn-editar,
        td button.btn-excluir {
            white-space: nowrap;
        }

        /* Melhorando a responsividade em telas menores */
        @media (max-width: 768px) {

            table,
            thead,
            tbody,
            th,
            td,
            tr {
                display: block;
            }

            th,
            td {
                padding: 10px;
                text-align: left;
            }

            tr {
                margin-bottom: 15px;
                border-bottom: 2px solid #2596be;
            }

            th {
                background-color: #2596be;
                color: #000;
            }
        }


        .btn {
            padding: 5px 10px;
            background-color: #2596be;
            color: #000;
            border: none;
            cursor: pointer;
        }

        .btn-excluir {
            padding: 5px 10px;
            background-color: #dc3545;
            color: #000;
            border: none;
            cursor: pointer;
        }

        .btn-editar {
            padding: 5px 10px;
            background-color: #2596be;
            color: #000;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #2596be;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 7px 10px;
            background-color: #151718;
            color: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .logo {
            font-size: 10px;
            color: #e0dede;
        }

        header .search-bar input {
            padding: 5px;
            width: 300px;
            border: 1px solid #454444;
            border-radius: 8px;
            background: #232424;
            color: #ffffff;
            box-shadow: inset 0 1px 3px rgba(243, 242, 242, 0.1);
        }

        header .search-bar input:focus {
            border-color: #007BFF;
            outline: none;
        }

        .btn-voltar img {
            width: 50px;
            height: 50px;
            object-fit: contain;
            transition: transform 0.2s ease;
        }

        .btn-voltar:hover {
            transform: scale(1.1);
        }

        .text {
            font-size: 11px;
            text-align: center;
            color: #888;
            bottom: 10px;
            width: 100%;
        }

        .toggle-btn {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #2596be;
            margin-left: 10px;
        }

        .section-content {
            display: block;
        }

        .section-content.hidden {
            display: none;
        }

        .hidden {
            display: none;
        }

        .toggle-btn {
            cursor: pointer;
            background: none;
            border: none;
            font-size: 20px;
            font-weight: bold;
            color: #333;
            padding: 0;
            margin: 0;
        }
    </style>
</head>

<body>
    <header>
        <div class="logo"><img src="images/site2.png" alt="Logo" style="width: 4.7rem;"></div>
        <div class="search-bar">
            <h1 class="text">Página para administrar nosso site.</h1>
        </div>

        <div class="titulo-carrinho">
            <h2>Painel Admin</h2>
        </div>
    </header>
    <nav>
        <div>
            <a href="#pedidos">Pedidos</a>
            <a href="#produtos">Produtos</a>
            <a href="#vendedores">Lojas</a>
            <a href="#vendedores">Notas Fiscais</a>
            <a href="#vendedores">Vendedores</a>
            <a href="#vendedores">Clientes</a>
        </div>
        <div>
            <a href="logout.php">Sair</a>
        </div>
    </nav>

    <div class="container">
        <section id="pedidos">
            <h2>Pedidos Finalizados
                <button class="toggle-btn" onclick="toggleSection(this)">➖</button>
            </h2>
            <div class="section-content">
                <?php
                $sql = "SELECT
            nf.id_nota,
            nf.id_venda,
            nf.nome_produto,
            nf.descricao,
            nf.imagem,
            nf.preco_unitario,
            nf.quantidade,
            nf.nome_loja,
            nf.endereco_loja,
            nf.telefone_loja,
            nf.cnpj_loja,
            nf.cpf_loja,
            nf.nome_vendedor,
            nf.email_vendedor,
            nf.data_registro,
            c.nome AS cliente_nome,
            c.email AS cliente_email,
            c.telefone AS cliente_telefone
        FROM nota_fiscal nf
        JOIN venda v ON nf.id_venda = v.id_venda
        JOIN cliente c ON v.id_cliente = c.id_cliente
        ORDER BY nf.id_venda DESC, nf.id_nota ASC";

                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    $vendaAnterior = null;
                    $totalVenda = 0;

                    while ($row = $result->fetch_assoc()) {
                        // Novo pedido?
                        if ($vendaAnterior !== $row['id_venda']) {
                            if ($vendaAnterior !== null) {
                                echo "<tr><td colspan='6' style='text-align: right;'><strong>Total:</strong></td><td colspan='2'><strong>R$ " . number_format($totalVenda, 2, ',', '.') . "</strong></td></tr></table><br>";
                                $totalVenda = 0;
                            }

                            echo "<h3 style='margin-top: 30px;'>Pedido #{$row['id_venda']}</h3>";

                            echo "<div style='display: flex; justify-content: space-between; margin-bottom: 20px;'>";

                            // Cliente
                            echo "<div style='flex: 1; padding: 10px;'>
                            <p style='font-size: 24px; font-weight: bold;'>Informações do Cliente:</p>";
                            $numero_wa_cliente = preg_replace('/\D/', '', $row['cliente_telefone']);
                            $link_wa_cliente = "https://wa.me/55{$numero_wa_cliente}";
                            echo "<p><strong>Nome:</strong> {$row['cliente_nome']}</p>
                          <p><strong>Email:</strong> <a href='mailto:{$row['cliente_email']}' style='text-decoration: none; color: #fff;'>{$row['cliente_email']}</a></p>
                          <p><strong>Telefone:</strong> <a href='{$link_wa_cliente}' style='text-decoration: none; color: #25D366;' target='_blank'>{$row['cliente_telefone']}</a></p>
                          </div>";

                            // Loja
                            echo "<div style='flex: 1; padding: 10px;'>
                            <p style='font-size: 24px; font-weight: bold;'>Informações da Loja:</p>";
                            $numero_wa_loja = preg_replace('/\D/', '', $row['telefone_loja']);
                            $link_wa_loja = "https://wa.me/55{$numero_wa_loja}";
                            echo "<p><strong>Loja:</strong> {$row['nome_loja']}</p>
                          <p><strong>Endereço:</strong> {$row['endereco_loja']}</p>
                          <p><strong>Telefone:</strong> <a href='{$link_wa_loja}' style='text-decoration: none; color: #25D366;' target='_blank'>{$row['telefone_loja']}</a></p>
                          <p><strong>CNPJ:</strong> {$row['cnpj_loja']}</p>
                          <p><strong>CPF:</strong> {$row['cpf_loja']}</p>
                          </div>";

                            // Vendedor
                            echo "<div style='flex: 1; padding: 10px;'>
                            <p style='font-size: 24px; font-weight: bold;'>Informações do Vendedor:</p>
                            <p><strong>Nome:</strong> {$row['nome_vendedor']}</p>
                            <p><strong>Email:</strong> <a href='mailto:{$row['email_vendedor']}' style='text-decoration: none; color: #fff;'>{$row['email_vendedor']}</a></p>
                          </div>";

                            echo "</div>";

                            echo "<table style='width: 100%; border-collapse: collapse;'>
                            <tr>
                                <th>Imagem</th>
                                <th>Produto</th>
                                <th>Descrição</th>
                                <th>Preço Unitário</th>
                                <th>Quantidade</th>
                                <th>Subtotal</th>
                                <th>ID Nota</th>
                                <th>Data Registro</th>
                            </tr>";

                            $vendaAnterior = $row['id_venda'];
                        }

                        $subtotal = $row['preco_unitario'] * $row['quantidade'];
                        $totalVenda += $subtotal;

                        $imgPath = !empty($row['imagem']) ? "uploads/{$row['imagem']}" : "uploads/sem-imagem.png";
                        echo "<tr>
                        <td><img src='{$imgPath}' alt='Imagem' style='width: 50px; height: 50px; object-fit: cover; border-radius: 5px; border: 1px solid #444;'></td>
                        <td>{$row['nome_produto']}</td>
                        <td>{$row['descricao']}</td>
                        <td>R$ " . number_format($row['preco_unitario'], 2, ',', '.') . "</td>
                        <td>{$row['quantidade']}</td>
                        <td>R$ " . number_format($subtotal, 2, ',', '.') . "</td>
                        <td>{$row['id_nota']}</td>
                        <td>{$row['data_registro']}</td>
                      </tr>";
                    }

                    echo "<tr><td colspan='6' style='text-align: right;'><strong>Total:</strong></td><td colspan='2'><strong>R$ " . number_format($totalVenda, 2, ',', '.') . "</strong></td></tr></table>";
                } else {
                    echo "<p>Nenhuma nota fiscal encontrada.</p>";
                }
                ?>
            </div>
        </section>

        <section id="produtos">
            <h2>Gerenciar Produtos
                <button class="toggle-btn" onclick="toggleSection(this)">➖</button>
            </h2>
            <div class="section-content">
                <?php
                $sql = "SELECT 
                p.id_produto, 
                p.nome, 
                p.preco, 
                p.imagem,
                l.id_loja,
                l.nome AS nome_loja,
                v.nome AS nome_vendedor
            FROM produto p
            LEFT JOIN loja l ON p.id_loja = l.id_loja
            LEFT JOIN vendedor v ON p.id_vendedor = v.id_vendedor";

                $result = $conn->query($sql);

                echo "<table>
            <tr>
                <th>ID</th>
                <th>Imagem</th>
                <th>Nome</th>
                <th>Preço</th>
                <th>ID Loja</th>
                <th>Nome Loja</th>
                <th>Vendedor</th>
                <th>Ações</th>
            </tr>";

                while ($p = $result->fetch_assoc()) {
                    $caminhoImagem = !empty($p['imagem']) ? "uploads/{$p['imagem']}" : "uploads/sem-imagem.png";

                    $imgTag = "<img src='{$caminhoImagem}' alt='Imagem Produto' style='width: 50px; height: 50px; object-fit: cover; border-radius: 5px; border: 1px solid #444;'>";

                    echo "<tr>
                <td>{$p['id_produto']}</td>
                <td>$imgTag</td>
                <td>{$p['nome']}</td>
                <td>R$ " . number_format($p['preco'], 2, ',', '.') . "</td>
                <td>" . ($p['id_loja'] ?? 'N/A') . "</td>
                <td>" . ($p['nome_loja'] ?? 'N/A') . "</td>
                <td>" . ($p['nome_vendedor'] ?? 'N/A') . "</td>
                <td>
                    <a href='editar_produto_admin.php?id={$p['id_produto']}' class='btn-editar'>Editar</a>
                    <button class='btn-excluir' onclick=\"confirmarExclusao('produto', {$p['id_produto']})\">Excluir</button>
                </td>
            </tr>";
                }

                echo "</table>";
                ?>
            </div>
        </section>

        <section id="lojas">
            <h2>Gerenciar Lojas
                <button class="toggle-btn" onclick="toggleSection(this)">➖</button>
            </h2>
            <div class="section-content">
                <?php
                $result = $conn->query("SELECT * FROM loja");
                echo "<table><tr><th>ID</th><th>Nome</th><th>Endereço</th><th>Telefone</th><th>CNPJ</th><th>CPF</th><th>Ações</th></tr>";
                while ($loja = $result->fetch_assoc()) {
                    echo "<tr>
                <td>{$loja['id_loja']}</td>
                <td>{$loja['nome']}</td>
                <td>{$loja['endereco']}</td>
                <td>{$loja['telefone']}</td>
                <td>{$loja['cnpj']}</td>
                <td>{$loja['cpf']}</td>
                <td>
                    <a href='admin_editar_loja.php?id={$loja['id_loja']}' class='btn-editar'>Editar</a>
                    <form method='POST' action='admin_excluir_loja.php' style='display:inline;' onsubmit=\"return confirm('Tem certeza que deseja excluir esta loja?');\">
                        <input type='hidden' name='id_loja' value='{$loja['id_loja']}'>
                        <button type='submit' class='btn-excluir'>Excluir</button>
                    </form>
                </td>
            </tr>";
                }
                echo "</table>";
                ?>
            </div>
        </section>

        <section id="notas">
            <h2>Notas Fiscais Emitidas
                <button class="toggle-btn" onclick="toggleSection(this)">➖</button>
            </h2>
            <div class="section-content">
                <?php
                $result = $conn->query("SELECT * FROM nota_fiscal ORDER BY data_registro DESC");
                echo "<table><tr><th>ID</th><th>Produto</th><th>Preço Unitário</th><th>Quantidade</th><th>Data</th><th>Vendedor</th></tr>";
                while ($n = $result->fetch_assoc()) {
                    echo "<tr>
            <td>{$n['id_nota']}</td>
            <td>{$n['nome_produto']}</td>
            <td>R$ " . number_format($n['preco_unitario'], 2, ',', '.') . "</td>
            <td>{$n['quantidade']}</td>
            <td>{$n['data_registro']}</td>
            <td>{$n['nome_vendedor']}</td>
        </tr>";
                }
                echo "</table>";
                ?>
            </div>
        </section>

        <section id="vendedores">
            <h2>Gerenciar Vendedores
                <button class="toggle-btn" onclick="toggleSection(this)">➖</button>
            </h2>
            <div class="section-content">
                <?php
                $sql = "SELECT v.id_vendedor, v.nome, v.email, l.nome AS nome_loja
                FROM vendedor v
                LEFT JOIN loja l ON v.id_loja = l.id_loja";

                $result = $conn->query($sql);

                echo "<table>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Loja</th>
                    <th>Ações</th>
                </tr>";

                while ($vendedor = $result->fetch_assoc()) {
                    echo "<tr>
                    <td>{$vendedor['id_vendedor']}</td>
                    <td>{$vendedor['nome']}</td>
                    <td>{$vendedor['email']}</td>
                    <td>" . ($vendedor['nome_loja'] ?? 'N/A') . "</td>
                    <td>
                        <a href='../editar_vendedor.php?id={$vendedor['id_vendedor']}' class='btn-editar'>Editar</a>
                        <button class='btn-excluir' onclick=\"confirmarExclusao('vendedor', {$vendedor['id_vendedor']})\">Excluir</button>
                    </td>
                </tr>";
                }

                echo "</table>";
                ?>
            </div>
        </section>



        <section id="clientes">
            <h2>Gerenciar Clientes
                <button class="toggle-btn" onclick="toggleSection(this)">➖</button>
            </h2>
            <div class="section-content">
                <?php
                $result = $conn->query("SELECT id_cliente, nome, email, telefone, tipo FROM cliente");
                echo "<table>
                        <tr><th>ID</th><th>Nome</th><th>Email</th><th>Telefone</th><th>Tipo</th><th>Ações</th></tr>";
                while ($c = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$c['id_cliente']}</td>
                        <td>{$c['nome']}</td>
                        <td>{$c['email']}</td>
                        <td>{$c['telefone']}</td>
                        <td>{$c['tipo']}</td>
                        <td>
                            <a href='../editar_cliente.php?id={$c['id_cliente']}' class='btn-editar'>Editar</a>
                            <button class='btn-excluir' onclick=\"confirmarExclusao('cliente', {$c['id_cliente']})\">Excluir</button>
                        </td>
                        </tr>";
                }
                echo "</table>";
                ?>
            </div>
        </section>



        <!-- Script para confirmação e redirecionamento com alerta -->
        <script>
            function confirmarExclusao(tipo, id) {
                let entidade = tipo;
                let mensagem = `Tem certeza que deseja excluir este ${entidade}?`;
                if (confirm(mensagem)) {
                    window.location.href = `excluir_${entidade}.php?id=${id}&redir=1&tipo=${entidade}`;
                }
            }


            window.addEventListener('DOMContentLoaded', () => {
                const params = new URLSearchParams(window.location.search);
                if (params.has('excluido') && params.get('excluido') === '1') {
                    const tipo = params.get('tipo');
                    let mensagem = 'Exclusão efetuada com sucesso!';
                    if (tipo === 'vendedor') mensagem = 'Vendedor excluído com sucesso!';
                    if (tipo === 'produto') mensagem = 'Produto excluído com sucesso!';
                    if (tipo === 'loja') mensagem = 'Loja excluída com sucesso!';
                    if (tipo === 'cliente') mensagem = 'Cliente excluído com sucesso!';

                    const alerta = document.createElement('div');
                    alerta.textContent = `✅ ${mensagem}`;
                    alerta.style.position = 'fixed';
                    alerta.style.top = '20px';
                    alerta.style.right = '20px';
                    alerta.style.backgroundColor = '#28a745';
                    alerta.style.color = 'white';
                    alerta.style.padding = '12px 20px';
                    alerta.style.borderRadius = '8px';
                    alerta.style.boxShadow = '0 2px 6px rgba(0,0,0,0.3)';
                    alerta.style.zIndex = 9999;
                    document.body.appendChild(alerta);

                    setTimeout(() => {
                        alerta.remove();
                        const url = new URL(window.location);
                        url.searchParams.delete('excluido');
                        url.searchParams.delete('tipo');
                        window.history.replaceState({}, document.title, url);
                    }, 3000);
                }
            });
        </script>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                // Seções com a classe 'section-content' e o botão de alternância
                const sections = document.querySelectorAll('.section-content');
                const buttons = document.querySelectorAll('.toggle-btn');

                // Inicializa todas as seções como ocultas
                sections.forEach(section => {
                    section.classList.add('hidden');
                });

                buttons.forEach(button => {
                    // Altera o ícone para "➕" inicialmente
                    button.textContent = "➕";

                    // Adiciona o evento para alternar a visibilidade
                    button.addEventListener('click', function() {
                        const section = this.parentElement.nextElementSibling;
                        if (section.classList.contains('hidden')) {
                            section.classList.remove('hidden');
                            this.textContent = "➖"; // Troca para "➖" quando a seção estiver visível
                        } else {
                            section.classList.add('hidden');
                            this.textContent = "➕"; // Troca para "➕" quando a seção estiver oculta
                        }
                    });
                });
            });
        </script>


</body>

</html>