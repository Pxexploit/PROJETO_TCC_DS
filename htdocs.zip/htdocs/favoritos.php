<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'cliente') {
    header("Location: login.php");
    exit();
}

$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "sistema_login"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$cliente_id = $_SESSION['usuario_id'];

// Buscar produtos favoritos do cliente
$sql = "SELECT 
            produto.id_produto,
            produto.nome AS nome_produto, 
            produto.descricao, 
            produto.preco, 
            produto.imagem,  
            loja.nome AS nome_loja, 
            vendedor.nome AS nome_vendedor, 
            vendedor.email,
            loja.telefone,
            favoritos.data_adicionado
        FROM favoritos 
        INNER JOIN produto ON favoritos.id_produto = produto.id_produto
        INNER JOIN loja ON produto.id_loja = loja.id_loja
        INNER JOIN vendedor ON vendedor.id_loja = loja.id_loja
        WHERE favoritos.id_cliente = ?
        ORDER BY favoritos.data_adicionado DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $cliente_id);
$stmt->execute();
$result = $stmt->get_result();

$produtos_favoritos = [];
while ($row = $result->fetch_assoc()) {
    $produtos_favoritos[] = $row;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Meus Favoritos - TaquaMarket</title>
    <link rel="stylesheet" href="css/telaproduto.css">
</head>
<body>

<header>
    <div class="logo">
        <img src="images/site2.png" alt="Logo" style="width: 4.7rem;">
    </div>
    <div class="search-bar">
        <h2 style="color: #e0dede; margin: 0;">Meus Favoritos</h2>
    </div>

    <div class="filters">
        <a href="telaprodutos.php" class="btn-voltar-header">
            <img src="images/voltar.png" alt="Voltar">
        </a>
        <a href="carrinho.php" class="cart-button">
            <img src="images/carrinho.png" alt="Carrinho de Compras" style="width: 2.5rem;">
        </a>
    </div>
</header>

<section class="product-list" id="product-list">
    <?php
    if (count($produtos_favoritos) > 0) {
        foreach ($produtos_favoritos as $produto) {
            ?>
            <div class="product-card" data-produto-id="<?php echo $produto['id_produto']; ?>">
                <img src="uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome_produto']); ?>">
                <div class="product-details">
                    <h3 class="product-name"><?php echo htmlspecialchars($produto['nome_produto']); ?></h3>
                    <p class="product-description"><?php echo htmlspecialchars($produto['descricao']); ?></p>
                    <span class="product-price">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></span><br>
                    <span class="product-store">Loja: <?php echo htmlspecialchars($produto['nome_loja']); ?></span><br>
                    <span class="product-seller">Vendedor: <?php echo htmlspecialchars($produto['nome_vendedor']); ?></span>

                    <div class="button-group">
                        <a href="https://wa.me/<?php echo preg_replace('/\D/', '', $produto['telefone']); ?>" class="contact-button" target="_blank">
                            Contato via WhatsApp
                        </a>
                        <button class="favorite-button" data-produto-id="<?php echo $produto['id_produto']; ?>" data-favorito="1">
                            <span class="heart-icon favorited">♥</span>
                        </button>
                        <a href="telaprodutos.php?produto=<?php echo $produto['id_produto']; ?>" class="add-cart-button">
                            <img src="images/addcarrinho.png" alt="Adicionar ao Carrinho" style="width: 2rem;">
                        </a>
                    </div>
                </div>
            </div>
            <?php
        }
    } else {
        echo "<div style='width: 100%; text-align: center; padding: 50px; color: #e0dede;'>";
        echo "<h2>Você ainda não tem produtos favoritos</h2>";
        echo "<p>Explore nossos produtos e adicione seus favoritos!</p>";
        echo "<a href='telaprodutos.php' style='color: #007bff; text-decoration: none;'>Ver Produtos</a>";
        echo "</div>";
    }
    ?>
</section>

<footer>
    <div class="footer-links">
        <a href="/sobre">Sobre</a>
        <a href="/politica-privacidade">Política de Privacidade</a>
        <a href="/termos-uso">Termos de Uso</a>
    </div>
    <div class="footer-info">
        <p>© 2025 TaquaMarket. Todos os direitos reservados.</p>
    </div>
</footer>

<script>
// Função para exibir notificações
function showNotification(message, type = 'success') {
    // Remove notificações existentes
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Cria nova notificação
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Adiciona ao body
    document.body.appendChild(notification);
    
    // Mostra a notificação
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Remove após 3 segundos
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 3000);
}

function toggleFavorite(button) {
    var produtoId = button.getAttribute('data-produto-id');
    var heartIcon = button.querySelector('.heart-icon');
    var isFavorited = heartIcon.classList.contains('favorited');
    
    // Criar FormData para enviar via POST
    var formData = new FormData();
    formData.append('action', 'toggle');
    formData.append('produto_id', produtoId);
    
    // Fazer requisição AJAX
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'favoritos_handler.php', true);
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            try {
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    if (response.favorited) {
                        heartIcon.classList.add('favorited');
                        button.setAttribute('data-favorito', '1');
                        showNotification('Produto adicionado aos favoritos com sucesso!', 'success');
                    } else {
                        heartIcon.classList.remove('favorited');
                        button.setAttribute('data-favorito', '0');
                        showNotification('Produto removido dos favoritos', 'warning');
                        // Remover o card da página se estiver na página de favoritos
                        if (window.location.pathname.includes('favoritos.php')) {
                            button.closest('.product-card').remove();
                        }
                    }
                } else {
                    alert('Erro: ' + response.message);
                }
            } catch (e) {
                console.error('Erro ao processar resposta:', e);
                alert('Erro ao processar resposta do servidor');
            }
        }
    };
    
    xhr.send(formData);
}

function initializeFavorites() {
    // Adicionar event listeners para todos os botões de favorito
    var favoriteButtons = document.querySelectorAll('.favorite-button');
    favoriteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            toggleFavorite(this);
        });
    });
}

// Inicializar favoritos quando a página carregar
document.addEventListener('DOMContentLoaded', function() {
    initializeFavorites();
});
</script>

</body>
</html>

<?php $conn->close(); ?>
