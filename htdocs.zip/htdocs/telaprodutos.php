<?php
session_start();

if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['usuario_tipo'], ['cliente', 'vendedor'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "sistema_login"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$categoryFilter = isset($_GET['category']) ? $_GET['category'] : 'todos';

$MAX_PRICE_ALLOWED = 9999999999.99;
$MIN_PRICE_ALLOWED = 0;

function sanitize_price($price, $min, $max) {
    if (!is_numeric($price)) return $min;
    $price = floatval($price);
    if ($price < $min) return $min;
    if ($price > $max) return $max;
    return $price;
}

$minPrice = isset($_GET['min-price']) ? sanitize_price($_GET['min-price'], $MIN_PRICE_ALLOWED, $MAX_PRICE_ALLOWED) : $MIN_PRICE_ALLOWED;
$maxPrice = isset($_GET['max-price']) ? sanitize_price($_GET['max-price'], $MIN_PRICE_ALLOWED, $MAX_PRICE_ALLOWED) : $MAX_PRICE_ALLOWED;

if ($minPrice > $maxPrice) {
    $maxPrice = $minPrice;
}

$sql = "SELECT 
            produto.id_produto,
            produto.nome AS nome_produto, 
            produto.descricao, 
            produto.preco, 
            produto.imagem,  
            loja.nome AS nome_loja, 
            vendedor.nome AS nome_vendedor, 
            vendedor.email,
            loja.telefone,
            CASE WHEN f.id_favorito IS NOT NULL THEN 1 ELSE 0 END as is_favorito
        FROM produto 
        INNER JOIN loja ON produto.id_loja = loja.id_loja
        INNER JOIN vendedor ON vendedor.id_loja = loja.id_loja
        LEFT JOIN favoritos f ON produto.id_produto = f.id_produto AND f.id_cliente = ?
        WHERE produto.preco BETWEEN ? AND ?";

$cliente_id = isset($_SESSION['usuario_id']) && $_SESSION['usuario_tipo'] === 'cliente' ? $_SESSION['usuario_id'] : 0;

if ($categoryFilter !== 'todos') {
    // Mapear categorias para termos de busca mais específicos
    $categoryMap = [
        'eletrodomesticos' => ['geladeira', 'fogão', 'microondas', 'máquina de lavar', 'secadora', 'ar condicionado', 'ventilador', 'liquidificador', 'batedeira', 'cafeteira'],
        'eletronicos' => ['celular', 'smartphone', 'tablet', 'notebook', 'computador', 'tv', 'televisão', 'som', 'caixa de som', 'fone', 'mouse', 'teclado'],
        'moveis' => ['mesa', 'cadeira', 'sofá', 'estante', 'armário', 'cama', 'guarda-roupa', 'rack', 'prateleira', 'banco'],
        'roupas' => ['camisa', 'calça', 'vestido', 'blusa', 'short', 'bermuda', 'jaqueta', 'casaco', 'saia', 'conjunto'],
        'calcados' => ['tênis', 'sapato', 'sandália', 'chinelo', 'bota', 'salto', 'sapatilha', 'all star'],
        'acessorios' => ['bolsa', 'mochila', 'carteira', 'relógio', 'óculos', 'colar', 'pulseira', 'brinco', 'anel'],
        'casa' => ['decoração', 'quadro', 'vaso', 'cortina', 'tapete', 'almofada', 'luminária', 'espelho'],
        'esporte' => ['academia', 'futebol', 'basquete', 'natação', 'corrida', 'ciclismo', 'musculação', 'yoga'],
        'livros' => ['livro', 'revista', 'gibi', 'mangá', 'romance', 'ficção', 'didático', 'infantil'],
        'beleza' => ['perfume', 'maquiagem', 'shampoo', 'condicionador', 'creme', 'sabonete', 'desodorante'],
        'automoveis' => ['carro', 'moto', 'bicicleta', 'pneu', 'óleo', 'bateria', 'peça', 'acessório automotivo']
    ];
    
    if (isset($categoryMap[$categoryFilter])) {
        $searchTerms = $categoryMap[$categoryFilter];
        $searchConditions = [];
        $bindTypes = "idd";
        $bindValues = [$cliente_id, $minPrice, $maxPrice];
        
        foreach ($searchTerms as $term) {
            $searchConditions[] = "produto.descricao LIKE ? OR produto.nome LIKE ?";
            $bindTypes .= "ss";
            $bindValues[] = '%' . $term . '%';
            $bindValues[] = '%' . $term . '%';
        }
        
        $sql .= " AND (" . implode(' OR ', $searchConditions) . ")";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($bindTypes, ...$bindValues);
    } else {
        // Fallback para busca genérica
        $sql .= " AND (produto.descricao LIKE ? OR produto.nome LIKE ?)";
        $stmt = $conn->prepare($sql);
        $searchCategoria = '%' . $categoryFilter . '%';
        $stmt->bind_param("iddss", $cliente_id, $minPrice, $maxPrice, $searchCategoria, $searchCategoria);
    }
} else {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("idd", $cliente_id, $minPrice, $maxPrice);
}

$stmt->execute();
$result = $stmt->get_result();

$produtos = [];
while ($row = $result->fetch_assoc()) {
    $produtos[$row['id_produto']] = $row;
}

if (isset($_GET['produto']) && isset($produtos[$_GET['produto']]) && !isset($_GET['added'])) {
    $id = intval($_GET['produto']);
    $preco_produto = $produtos[$id]['preco'];

    if (!isset($_SESSION['carrinho'])) {
        $_SESSION['carrinho'] = [];
    }

    if (!isset($_SESSION['carrinho'][$id])) {
        $_SESSION['carrinho'][$id] = 0;
    }
    $_SESSION['carrinho'][$id]++;

    if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_tipo'] === 'cliente') {
        $usuario_id = $_SESSION['usuario_id'];
        $produto_id = $id;
        $quantidade = 1;
        $valor_unitario = $preco_produto;

        $stmt_venda = $conn->prepare("SELECT id_venda FROM venda WHERE id_cliente = ? AND status = 'carrinho'");
        $stmt_venda->bind_param("i", $usuario_id);
        $stmt_venda->execute();
        $result_venda = $stmt_venda->get_result();

        if ($result_venda->num_rows > 0) {
            $venda = $result_venda->fetch_assoc();
            $id_venda = $venda['id_venda'];
        } else {
            $stmt_nova = $conn->prepare("INSERT INTO venda (id_cliente, status) VALUES (?, 'carrinho')");
            $stmt_nova->bind_param("i", $usuario_id);
            $stmt_nova->execute();
            $id_venda = $stmt_nova->insert_id;
        }

        $stmt_check = $conn->prepare("SELECT item_quantidade FROM item_venda WHERE id_venda = ? AND id_produto = ?");
        $stmt_check->bind_param("ii", $id_venda, $produto_id);
        $stmt_check->execute();
        $res_check = $stmt_check->get_result();

        if ($res_check->num_rows > 0) {
            $stmt_update = $conn->prepare("UPDATE item_venda SET item_quantidade = item_quantidade + 1 WHERE id_venda = ? AND id_produto = ?");
            $stmt_update->bind_param("ii", $id_venda, $produto_id);
            $stmt_update->execute();
        } else {
            $stmt = $conn->prepare("INSERT INTO item_venda (id_venda, id_produto, item_quantidade, item_valor) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiid", $id_venda, $produto_id, $quantidade, $valor_unitario);
            $stmt->execute();
        }
    }

    header('Location: ' . $_SERVER['PHP_SELF'] . '?added=' . $id);
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Marketplace - Produtos</title>
    <link rel="stylesheet" href="css/telaproduto.css">
</head>
<body>

<div id="mensagemCarrinho" style="display: none;">
    Apenas clientes têm acesso ao carrinho.
</div>


<header>
    <div class="logo">
        <img src="images/site2.png" alt="Logo" style="width: 4.7rem;">
    </div>
    <div class="search-bar">
        <input type="text" placeholder="Buscar produtos..." id="search-input" oninput="searchProducts()" autocomplete="off">
    </div>

    <div class="filters">
        <a href="../php/<?php echo $_SESSION['usuario_tipo'] === 'vendedor' ? 'siteVendedor.php' : 'site.php'; ?>" class="btn-voltar-header">
            <img src="images/voltar.png" alt="Voltar">
        </a>

        <?php
            $ehCliente = isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] === 'cliente';
            $linkCarrinho = $ehCliente ? 'carrinho.php' : '#';
            $eventoClique = $ehCliente ? '' : 'onclick="exibirMensagemCarrinho(); return false;"';
        ?>
        <?php if ($ehCliente): ?>
        <a href="favoritos.php" class="favorites-button" style="margin-right: 10px;">
            <span style="font-size: 2rem; color: #ff4757;">♥</span>
        </a>
        <a href="chat.php" class="chat-header-button" style="margin-right: 10px;" title="Mensagens">
            <span style="font-size: 2rem; color: #28a745;">💬</span>
        </a>
        <?php elseif ($_SESSION['usuario_tipo'] === 'vendedor'): ?>
        <a href="chat.php" class="chat-header-button" style="margin-right: 10px;" title="Mensagens">
            <span style="font-size: 2rem; color: #28a745;">💬</span>
        </a>
        <?php endif; ?>
        <a href="<?php echo $linkCarrinho; ?>" class="cart-button" <?php echo $eventoClique; ?>>
            <img src="images/carrinho.png" alt="Carrinho de Compras" style="width: 2.5rem;">
        </a>
    </div>
</header>

<div class="filters-container">
    <div class="filters-header" onclick="toggleFilters()">
        <h3>🔍 Filtros</h3>
        <span class="toggle-icon" id="toggle-icon">▶</span>
    </div>
    
    <div class="filters-section collapsed" id="filters-section">
        <form action="" method="GET" id="filters-form">
            <div class="filter-group">
                <label for="category">Categoria:</label>
                <select name="category" id="category" onchange="applyFilters()">
                    <option value="todos" <?php echo $categoryFilter == 'todos' ? 'selected' : ''; ?>>Todas as Categorias</option>
                    <option value="eletrodomesticos" <?php echo $categoryFilter == 'eletrodomesticos' ? 'selected' : ''; ?>>Eletrodomésticos</option>
                    <option value="eletronicos" <?php echo $categoryFilter == 'eletronicos' ? 'selected' : ''; ?>>Eletrônicos</option>
                    <option value="moveis" <?php echo $categoryFilter == 'moveis' ? 'selected' : ''; ?>>Móveis</option>
                    <option value="roupas" <?php echo $categoryFilter == 'roupas' ? 'selected' : ''; ?>>Roupas</option>
                    <option value="calcados" <?php echo $categoryFilter == 'calcados' ? 'selected' : ''; ?>>Calçados</option>
                    <option value="acessorios" <?php echo $categoryFilter == 'acessorios' ? 'selected' : ''; ?>>Acessórios</option>
                    <option value="casa" <?php echo $categoryFilter == 'casa' ? 'selected' : ''; ?>>Casa e Decoração</option>
                    <option value="esporte" <?php echo $categoryFilter == 'esporte' ? 'selected' : ''; ?>>Esporte e Lazer</option>
                    <option value="livros" <?php echo $categoryFilter == 'livros' ? 'selected' : ''; ?>>Livros</option>
                    <option value="beleza" <?php echo $categoryFilter == 'beleza' ? 'selected' : ''; ?>>Beleza e Saúde</option>
                    <option value="automoveis" <?php echo $categoryFilter == 'automoveis' ? 'selected' : ''; ?>>Automóveis</option>
                </select>
            </div>
            <br>
            <div class="filter-group">
                <label for="min-price">Preço Mínimo:</label>
                <input type="number" placeholder="R$ 0,00" name="min-price" id="min-price" value="<?php echo isset($_GET['min-price']) ? $_GET['min-price'] : 0; ?>" onchange="applyFilters()">
            </div>
            <br>
            <div class="filter-group">
                <label for="max-price">Preço Máximo:</label>
                <input type="number" placeholder="R$ 999.999,00" name="max-price" id="max-price" value="<?php echo isset($_GET['max-price']) ? $_GET['max-price'] : 999999; ?>" onchange="applyFilters()">
            </div>
            <br>            
            <div class="filter-actions">
                <button type="button" onclick="clearFilters()" class="btn-clear-filters">Limpar Filtros</button>
                <button type="submit" class="btn-apply-filters">Aplicar Filtros</button>
            </div>
        </form>
    </div>
</div>

<section class="product-list" id="product-list">
    <?php
    if (count($produtos) > 0) {
        foreach ($produtos as $produto) {
            ?>
            <div class="product-card" data-produto-id="<?php echo $produto['id_produto']; ?>">
                <img src="uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" alt="<?php echo htmlspecialchars($produto['nome_produto']); ?>">
                <div class="product-details">
                    <h3 class="product-name"><?php echo htmlspecialchars($produto['nome_produto']); ?></h3>
                    <p class="product-description"><?php echo htmlspecialchars($produto['descricao']); ?></p>
                    <span class="product-price">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></span><br>
                    <span class="product-store">Loja: <?php echo htmlspecialchars($produto['nome_loja']); ?></span><br>
                    <span class="product-seller">Vendedor: <?php echo htmlspecialchars($produto['nome_vendedor']); ?></span>

                    <div class="button-group">
                        <a href="https://wa.me/<?php echo preg_replace('/\D/', '', $produto['telefone']); ?>" class="contact-button" target="_blank">
                            Contato via WhatsApp
                        </a>
                        <?php if ($_SESSION['usuario_tipo'] === 'cliente'): ?>
                        <button class="chat-button" data-produto-id="<?php echo $produto['id_produto']; ?>" title="Chat Interno">
                            💬
                        </button>
                        <button class="favorite-button" data-produto-id="<?php echo $produto['id_produto']; ?>" data-favorito="<?php echo $produto['is_favorito']; ?>">
                            <span class="heart-icon <?php echo $produto['is_favorito'] ? 'favorited' : ''; ?>">♥</span>
                        </button>
                        <?php endif; ?>
                        <a href="?produto=<?php echo $produto['id_produto']; ?>" class="add-cart-button">
                            <img src="images/addcarrinho.png" alt="Adicionar ao Carrinho" style="width: 2rem;">
                        </a>
                    </div>
                </div>
            </div>
            <?php
        }
    } else {
        echo "<p>Nenhum produto encontrado.</p>";
    }
    ?>
</section>

<footer>
    <div class="footer-links">
        <a href="/sobre">Sobre</a>
        <a href="/politica-privacidade">Política de Privacidade</a>
        <a href="/termos-uso">Termos de Uso</a>
    </div>
    <div class="footer-info">
        <p>© 2025 TaquaMarket. Todos os direitos reservados.</p>
    </div>
</footer>

<script>
// Função para exibir notificações
function showNotification(message, type = 'success') {
    // Remove notificações existentes
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Cria nova notificação
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Adiciona ao body
    document.body.appendChild(notification);
    
    // Mostra a notificação
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Remove após 3 segundos
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 3000);
}

// Função para alternar visibilidade dos filtros
function toggleFilters() {
    const filtersSection = document.getElementById('filters-section');
    const toggleIcon = document.getElementById('toggle-icon');
    
    if (filtersSection.classList.contains('collapsed')) {
        filtersSection.classList.remove('collapsed');
        toggleIcon.textContent = '▼';
    } else {
        filtersSection.classList.add('collapsed');
        toggleIcon.textContent = '▶';
    }
}

// Função para aplicar filtros automaticamente
function applyFilters() {
    const form = document.getElementById('filters-form');
    const formData = new FormData(form);
    const params = new URLSearchParams();
    
    for (let [key, value] of formData.entries()) {
        if (value && value !== 'todos') {
            params.append(key, value);
        }
    }
    
    const newUrl = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
    window.location.href = newUrl;
}

// Função para limpar todos os filtros
function clearFilters() {
    document.getElementById('category').value = 'todos';
    document.getElementById('min-price').value = '';
    document.getElementById('max-price').value = '';
    
    // Redirecionar para a página sem filtros
    window.location.href = window.location.pathname;
}

function searchProducts() {
    var query = document.getElementById('search-input').value.trim();  // Obtém o texto digitado
    var minPrice = document.getElementById('min-price').value.trim();  // Obtém o preço mínimo
    var maxPrice = document.getElementById('max-price').value.trim();  // Obtém o preço máximo

    if (query.length > 0 || minPrice.length > 0 || maxPrice.length > 0) {  // Se houver qualquer filtro
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "search_products.php?search=" + query + "&min-price=" + minPrice + "&max-price=" + maxPrice, true);  // URL do arquivo PHP com a pesquisa e filtros

        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Atualiza a seção de produtos com o retorno do PHP
                document.getElementById('product-list').innerHTML = xhr.responseText;
                // Reaplica os event listeners dos favoritos e chat após atualizar o conteúdo
                initializeFavorites();
                initializeChat();
            }
        };

        xhr.send();
    } else {
        // Se não houver nada digitado ou filtrado, exibe novamente todos os produtos
        location.reload();  // Isso vai recarregar a página e exibir todos os produtos novamente
    }
}

function toggleFavorite(button) {
    var produtoId = button.getAttribute('data-produto-id');
    var heartIcon = button.querySelector('.heart-icon');
    var isFavorited = heartIcon.classList.contains('favorited');
    
    // Criar FormData para enviar via POST
    var formData = new FormData();
    formData.append('action', 'toggle');
    formData.append('produto_id', produtoId);
    
    // Fazer requisição AJAX
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'favoritos_handler.php', true);
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            try {
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    if (response.favorited) {
                        heartIcon.classList.add('favorited');
                        button.setAttribute('data-favorito', '1');
                        showNotification('Produto adicionado aos favoritos com sucesso!', 'success');
                    } else {
                        heartIcon.classList.remove('favorited');
                        button.setAttribute('data-favorito', '0');
                        showNotification('Produto removido dos favoritos', 'warning');
                    }
                } else {
                    alert('Erro: ' + response.message);
                }
            } catch (e) {
                console.error('Erro ao processar resposta:', e);
                alert('Erro ao processar resposta do servidor');
            }
        }
    };
    
    xhr.send(formData);
}

function initializeFavorites() {
    // Adicionar event listeners para todos os botões de favorito
    var favoriteButtons = document.querySelectorAll('.favorite-button');
    favoriteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            toggleFavorite(this);
        });
    });
}

function initializeChat() {
    // Adicionar event listeners para todos os botões de chat
    var chatButtons = document.querySelectorAll('.chat-button');
    chatButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            iniciarChat(this);
        });
    });
}

function iniciarChat(button) {
    var produtoId = button.getAttribute('data-produto-id');
    
    // Criar FormData para enviar via POST
    var formData = new FormData();
    formData.append('produto_id', produtoId);
    
    // Fazer requisição AJAX
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'iniciar_conversa.php', true);
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            try {
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    // Redirecionar para o chat
                    window.location.href = 'chat.php?conversa=' + response.conversa_id;
                } else {
                    alert('Erro: ' + response.message);
                }
            } catch (e) {
                console.error('Erro ao processar resposta:', e);
                alert('Erro ao processar resposta do servidor');
            }
        }
    };
    
    xhr.send(formData);
}

// Verificar se há parâmetro de produto adicionado ao carrinho
document.addEventListener('DOMContentLoaded', function() {
    initializeFavorites();
    initializeChat();
    
    // Verificar se um produto foi adicionado ao carrinho
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('added')) {
        showNotification('Produto adicionado ao carrinho!', 'success');
        // Remove o parâmetro da URL para não mostrar novamente
        const newUrl = window.location.pathname;
        window.history.replaceState({}, document.title, newUrl);
    }
});
</script>

</body>
</html>

<?php $conn->close(); ?>
