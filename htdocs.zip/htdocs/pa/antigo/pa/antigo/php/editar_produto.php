<?php 
session_start();

if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    echo "Acesso negado.";
    exit();
}

$conn = new mysqli("localhost", "root", "", "sistema_login");
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

if (!isset($_GET['id'])) {
    echo "ID do produto não informado.";
    exit();
}

$id_produto = intval($_GET['id']);

$stmt = $conn->prepare("SELECT p.* FROM produto p 
                        INNER JOIN loja l ON p.id_loja = l.id_loja 
                        INNER JOIN vendedor v ON l.id_loja = v.id_loja 
                        WHERE p.id_produto = ? AND v.email = ?");
$stmt->bind_param("is", $id_produto, $_SESSION['usuario_email']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Produto não encontrado ou não pertence a você.";
    exit();
}

$produto = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $preco = floatval($_POST['preco']);
    $imagem = $produto['imagem'];

    if ($_FILES['nova_imagem']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['nova_imagem']['name'], PATHINFO_EXTENSION);
        $novo_nome = uniqid() . '.' . $ext;
        move_uploaded_file($_FILES['nova_imagem']['tmp_name'], "../uploads/$novo_nome");
        $imagem = $novo_nome;
    }

    $stmt_update = $conn->prepare("UPDATE produto SET nome = ?, descricao = ?, preco = ?, imagem = ? WHERE id_produto = ?");
    $stmt_update->bind_param("ssdsi", $nome, $descricao, $preco, $imagem, $id_produto);

    if ($stmt_update->execute()) {
        header("Location: meus_produtos.php");
        exit();
    } else {
        echo "Erro ao atualizar produto.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Produto</title>
    <link rel="stylesheet" href="../css/editar_produtos.css">
</head>
<body>

<div class="container">
    <h2>Editar Produto</h2>

    <form method="POST" enctype="multipart/form-data">
        <label for="nome">Nome do Produto:</label>
        <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($produto['nome']); ?>" required>

        <label for="descricao">Descrição:</label>
        <textarea id="descricao" name="descricao" required><?php echo htmlspecialchars($produto['descricao']); ?></textarea>

        <label for="preco">Preço:</label>
        <input type="number" id="preco" step="0.01" name="preco" value="<?php echo $produto['preco']; ?>" required>

        <label>Imagem Atual:</label>
        <?php if (!empty($produto['imagem'])): ?>
            <img id="imagemAtual" src="../uploads/<?php echo htmlspecialchars($produto['imagem']); ?>" alt="Imagem do Produto" style="max-width: 200px;">
        <?php else: ?>
            <p>Sem imagem cadastrada.</p>
        <?php endif; ?>

        <label for="nova_imagem">Nova Imagem (opcional):</label>
        <input type="file" name="nova_imagem" id="nova_imagem">

        <button type="submit">Salvar Alterações</button>
    </form>
</div>

<script>
document.getElementById('nova_imagem').addEventListener('change', function(event) {
    const file = event.target.files[0];
    const preview = document.getElementById('imagemAtual');

    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});
</script>

</body>
</html>
