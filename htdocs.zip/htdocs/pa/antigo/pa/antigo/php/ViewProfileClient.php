<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'cliente') {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_login";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$id_cliente = $_SESSION['usuario_id'];

$sql = "SELECT * FROM cliente WHERE id_cliente = $id_cliente";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $cliente = $result->fetch_assoc();
} else {
    echo "Cliente não encontrado.";
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Meu Perfil - Cliente</title>
    <link rel="stylesheet" href="../css/perfil_vendedor.css">
    <style>
        .aviso-senha {
            color: #e0dede;
            font-size: 0.95rem;
            margin: 15px 0 25px;
            text-align: center;
        }

        .btn-editar {
            background-color: rgb(217, 83, 1);
            color: #fff;
        }

        .btn-editar:hover {
            background-color: rgb(180, 65, 0);
        }
    </style>
</head>
<body>
    <div class="perfil-container">
        <h1>Meu Perfil</h1>

        <div class="info-item">
            <label>Nome:</label>
            <p><?php echo htmlspecialchars($cliente['nome']); ?></p>
        </div>

        <div class="info-item">
            <label>Email:</label>
            <p><?php echo htmlspecialchars($cliente['email']); ?></p>
        </div>
        
        <div class="info-item">
            <label>Senha:</label>
            <div class="senha-aviso"><p>Altere a senha no botão <strong>Editar Perfil</strong></p></div>
        </div> 

        <form action="../php/perfil_cliente.php" method="GET">
            <button type="submit" class="btn-editar">Editar Perfil</button>
        </form>

        <form action="../php/site.php" method="GET">
            <button type="submit">Voltar para o Menu</button>
        </form>
    </div>
</body>
</html>
