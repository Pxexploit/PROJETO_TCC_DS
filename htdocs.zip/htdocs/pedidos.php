<?php
session_start();

// Verifica se o usuário está logado como "vendedor"
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'vendedor') {
    header("Location: login.php");
    exit();
}

$vendedor_id = $_SESSION['usuario_id'];

$conn = new mysqli("localhost", "root", "", "sistema_login");
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Obter a loja associada ao vendedor
$stmt = $conn->prepare("SELECT id_loja FROM vendedor WHERE id_vendedor = ?");
$stmt->bind_param("i", $vendedor_id);
$stmt->execute();
$result = $stmt->get_result();
$loja = $result->fetch_assoc();

$id_loja = $loja['id_loja'] ?? null;

//notificação de erro que tem que cadastrar loja para acessar a tela
if (!$id_loja) {
    $_SESSION['deubompdds'] = 'semlojapdds';
    header("Location: ../php/MenuVendedor.php");
    exit();
}

$id_loja = $loja['id_loja'];

// Ajustando a consulta para buscar os pedidos na tabela `nota_fiscal`
$sql = "SELECT 
            nf.id_nota AS id_venda, 
            nf.data_registro AS data, 
            nf.preco_unitario * nf.quantidade AS total, 
            c.nome AS nome_cliente, 
            c.telefone, 
            c.email, 
            nf.nome_produto AS produto_nome, 
            nf.quantidade AS item_quantidade, 
            nf.preco_unitario AS item_valor
        FROM nota_fiscal nf
        JOIN venda v ON nf.id_venda = v.id_venda
        JOIN cliente c ON v.id_cliente = c.id_cliente
        WHERE v.id_loja = ? AND v.status = 'finalizada'
        ORDER BY nf.data_registro DESC";


$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_loja);
$stmt->execute();
$pedidos = $stmt->get_result();

// Função para formatar o telefone
function formatar_telefone($telefone)
{
    $telefone = preg_replace('/\D/', '', $telefone);
    if (strlen($telefone) === 11) {
        return '(' . substr($telefone, 0, 2) . ') ' . substr($telefone, 2, 5) . '-' . substr($telefone, 7);
    }
    return $telefone;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Pedidos Recebidos</title>
    <link rel="stylesheet" href="css/pedidos.css">
</head>

<body>

    <header>
        <div class="logo"><img src="images/site2.png" alt="Logo" style="width: 4.7rem;"></div>
        <div class="search-bar">
            <input type="text" placeholder="Buscar produtos..." id="search-input">
        </div>

        <div class="titulo-carrinho">
            <h2>Pedidos</h2>
            <a href="../php/MenuVendedor.php" class="btn-voltar">
                <img src="images/voltar.png" alt="Voltar">
            </a>
        </div>
    </header>

    <section class="titulo-carrinho">
        <h2>Pedidos</h2>
    </section>

    <main class="pedidos-section">
        <?php if ($pedidos->num_rows > 0): ?>
            <table class="tabela-pedidos">
                <thead>
                    <tr>
                        <th>ID Venda</th>
                        <th>Data</th>
                        <th>Cliente</th>
                        <th>Email</th>
                        <th>Telefone</th>
                        <th>Produto</th>
                        <th>Quantidade</th>
                        <th>Valor Unitário</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($pedido = $pedidos->fetch_assoc()): ?>
                        <tr>
                            <td><?= $pedido['id_venda']; ?></td>
                            <td><?= date('d/m/Y', strtotime($pedido['data'])); ?></td>
                            <td><?= htmlspecialchars($pedido['nome_cliente']); ?></td>
                            <td><?= htmlspecialchars($pedido['email']); ?></td>
                            <?php
                            $numero_wa = preg_replace('/\D/', '', $pedido['telefone']); // Remove tudo que não for número
                            $link_wa = "https://wa.me/+55" . $numero_wa;
                            $telefone_formatado = formatar_telefone($pedido['telefone']);
                            ?>
                            <td>
                                <a href="<?= $link_wa ?>" target="_blank" style="text-decoration: none; color: #25D366;">
                                    <?= $telefone_formatado ?>
                                </a>
                            </td>
                            <td><?= htmlspecialchars($pedido['produto_nome']); ?></td>
                            <td><?= $pedido['item_quantidade']; ?></td>
                            <td>R$ <?= number_format($pedido['item_valor'], 2, ',', '.'); ?></td>
                            <td>R$ <?= number_format($pedido['item_valor'] * $pedido['item_quantidade'], 2, ',', '.'); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="nenhum-pedido">Nenhum pedido encontrado para sua loja.</p>
        <?php endif; ?>
    </main>

    <script>
        //script para dar o tempo da mensagem de erro da notificação
        setTimeout(function() {
            const mensagem = document.getElementById('mensagem-flash');
            if (mensagem) {
                mensagem.classList.add('desaparecer');
            }
        }, 4000); // 4 segundos
    </script>

</body>

</html>

<?php $conn->close(); ?>