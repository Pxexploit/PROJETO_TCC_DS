<?php
session_start();

if (!isset($_SESSION['usuario_email']) || $_SESSION['usuario_tipo'] !== 'admin') {
    echo "Acesso negado. Apenas administradores.";
    exit();
}

$conn = new mysqli("localhost", "root", "", "sistema_login");
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

if (!isset($_GET['id_loja'])) {
    echo "ID da loja não informado.";
    exit();
}

$id_loja = intval($_GET['id_loja']);

$conn->begin_transaction();
try {
    // Desvincular produtos
    $stmt_prod = $conn->prepare("UPDATE produto SET id_loja = NULL WHERE id_loja = ?");
    $stmt_prod->bind_param("i", $id_loja);
    $stmt_prod->execute();

    // Desvincular vendas
    $stmt_venda = $conn->prepare("UPDATE venda SET id_loja = NULL WHERE id_loja = ?");
    $stmt_venda->bind_param("i", $id_loja);
    $stmt_venda->execute();

    // Desvincular vendedores
    $stmt_vend = $conn->prepare("UPDATE vendedor SET id_loja = NULL WHERE id_loja = ?");
    $stmt_vend->bind_param("i", $id_loja);
    $stmt_vend->execute();

    // Excluir loja
    $stmt_del = $conn->prepare("DELETE FROM loja WHERE id_loja = ?");
    $stmt_del->bind_param("i", $id_loja);
    $stmt_del->execute();

    $conn->commit();
    echo "Loja excluída com sucesso.";
} catch (Exception $e) {
    $conn->rollback();
    echo "Erro ao excluir: " . $e->getMessage();
}
$conn->close();
