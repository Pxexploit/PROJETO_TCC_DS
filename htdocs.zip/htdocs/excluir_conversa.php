<?php
session_start();

if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['usuario_tipo'], ['cliente', 'vendedor'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_login";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

header('Content-Type: application/json');

$conversa_id = intval($_POST['conversa_id'] ?? 0);
$usuario_id = $_SESSION['usuario_id'];
$usuario_tipo = $_SESSION['usuario_tipo'];

if ($conversa_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Conversa inválida']);
    exit();
}

// Verificar se a conversa existe e o usuário tem acesso
$sql_verificar = "SELECT * FROM conversas WHERE id_conversa = ? AND (id_cliente = ? OR id_vendedor = ?)";
$stmt_verificar = $conn->prepare($sql_verificar);
$stmt_verificar->bind_param("iii", $conversa_id, $usuario_id, $usuario_id);
$stmt_verificar->execute();
$conversa = $stmt_verificar->get_result()->fetch_assoc();

if (!$conversa) {
    echo json_encode(['success' => false, 'message' => 'Conversa não encontrada']);
    exit();
}

// Buscar todas as mensagens com arquivos para excluir os arquivos físicos
$sql_arquivos = "SELECT arquivo_caminho FROM mensagens WHERE id_conversa = ? AND arquivo_caminho IS NOT NULL";
$stmt_arquivos = $conn->prepare($sql_arquivos);
$stmt_arquivos->bind_param("i", $conversa_id);
$stmt_arquivos->execute();
$arquivos = $stmt_arquivos->get_result();

// Excluir arquivos físicos
while ($arquivo = $arquivos->fetch_assoc()) {
    if (file_exists($arquivo['arquivo_caminho'])) {
        unlink($arquivo['arquivo_caminho']);
    }
}

// Excluir mensagens relacionadas (cascade já faz isso, mas vamos ser explícitos)
$sql_excluir_mensagens = "DELETE FROM mensagens WHERE id_conversa = ?";
$stmt_excluir_mensagens = $conn->prepare($sql_excluir_mensagens);
$stmt_excluir_mensagens->bind_param("i", $conversa_id);
$stmt_excluir_mensagens->execute();

// Excluir conversa
$sql_excluir_conversa = "DELETE FROM conversas WHERE id_conversa = ?";
$stmt_excluir_conversa = $conn->prepare($sql_excluir_conversa);
$stmt_excluir_conversa->bind_param("i", $conversa_id);

if ($stmt_excluir_conversa->execute()) {
    echo json_encode(['success' => true, 'message' => 'Conversa excluída com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao excluir conversa: ' . $conn->error]);
}

$conn->close();
?>
