<?php
session_start();

// Verificar se o usuário está logado e é cliente
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'cliente') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Apenas clientes podem usar favoritos']);
    exit();
}

$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "sistema_login"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$action = $_POST['action'] ?? '';
$produto_id = intval($_POST['produto_id'] ?? 0);
$cliente_id = $_SESSION['usuario_id'];

header('Content-Type: application/json');

if ($action === 'toggle') {
    // Verificar se o produto já está nos favoritos
    $stmt_check = $conn->prepare("SELECT id_favorito FROM favoritos WHERE id_cliente = ? AND id_produto = ?");
    $stmt_check->bind_param("ii", $cliente_id, $produto_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    
    if ($result_check->num_rows > 0) {
        // Remover dos favoritos
        $stmt_remove = $conn->prepare("DELETE FROM favoritos WHERE id_cliente = ? AND id_produto = ?");
        $stmt_remove->bind_param("ii", $cliente_id, $produto_id);
        
        if ($stmt_remove->execute()) {
            echo json_encode(['success' => true, 'favorited' => false, 'message' => 'Produto removido dos favoritos']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao remover dos favoritos']);
        }
    } else {
        // Adicionar aos favoritos
        $stmt_add = $conn->prepare("INSERT INTO favoritos (id_cliente, id_produto) VALUES (?, ?)");
        $stmt_add->bind_param("ii", $cliente_id, $produto_id);
        
        if ($stmt_add->execute()) {
            echo json_encode(['success' => true, 'favorited' => true, 'message' => 'Produto adicionado aos favoritos']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao adicionar aos favoritos']);
        }
    }
} elseif ($action === 'check') {
    // Verificar se o produto está nos favoritos
    $stmt_check = $conn->prepare("SELECT id_favorito FROM favoritos WHERE id_cliente = ? AND id_produto = ?");
    $stmt_check->bind_param("ii", $cliente_id, $produto_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    
    $favorited = $result_check->num_rows > 0;
    echo json_encode(['success' => true, 'favorited' => $favorited]);
} else {
    echo json_encode(['success' => false, 'message' => 'Ação inválida']);
}

$conn->close();
?>
