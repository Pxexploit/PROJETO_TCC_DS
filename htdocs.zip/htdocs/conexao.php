<?php
$servername = "localhost";
$username = "root";
$password = ""; // deixe em branco se não tiver senha no XAMPP
$dbname = "sistema_login";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>
