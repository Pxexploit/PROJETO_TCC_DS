<?php
// excluir_produto.php
session_start();
include('conexao.php');

if (!isset($_SESSION['id_cliente']) || $_SESSION['tipo'] !== 'admin') {
    echo "Acesso negado.";
    exit();
}

if (!isset($_GET['id'])) {
    echo "ID do produto não especificado.";
    exit();
}

$id_produto = (int)$_GET['id'];

$sql = "DELETE FROM produto WHERE id_produto = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_produto);

if ($stmt->execute()) {
    echo "<p style='color: green;'>Produto excluído com sucesso!</p>";
} else {
    echo "<p style='color: red;'>Erro ao excluir o produto.</p>";
}

echo '<a href="painelAdmin.php" style="color: lightblue;">Voltar ao Painel</a>';
?>
