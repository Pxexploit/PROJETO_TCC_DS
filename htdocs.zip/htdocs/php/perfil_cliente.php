<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'cliente') {
    header("Location: login.php");
    exit();
}

$mensagem = "";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_login";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$id_cliente = $_SESSION['usuario_id'];
$sql = "SELECT * FROM cliente WHERE id_cliente = $id_cliente";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $cliente = $result->fetch_assoc();
} else {
    echo "Cliente não encontrado.";
    exit();
}

// Função para formatar o telefone
function formatarTelefone($telefone) {
    $telefone = preg_replace('/\D/', '', $telefone); // Remove todos os caracteres não numéricos
    if (strlen($telefone) == 11) {
        return '(' . substr($telefone, 0, 2) . ') ' . substr($telefone, 2, 5) . '-' . substr($telefone, 7);
    }
    return $telefone; // Retorna o telefone sem formatação caso não tenha 11 dígitos
}

$telefone_formatado = formatarTelefone($cliente['telefone']);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $novo_nome = $_POST['nome'];
    $novo_email = $_POST['email'];
    $nova_senha = $_POST['senha'];
    $novo_telefone = preg_replace('/\D/', '', $_POST['telefone']); // Remove qualquer não número

    // Verifica se o e-mail já está em uso
    $email_existente = $conn->query("SELECT id_vendedor FROM vendedor WHERE email = '$novo_email'")->num_rows > 0;
    $email_em_uso = $conn->query("SELECT id_cliente FROM cliente WHERE email = '$novo_email' AND id_cliente != $id_cliente")->num_rows > 0;

    if ($email_existente || $email_em_uso) {
        $mensagem = "Erro: Este e-mail já está em uso por outro usuário.";
    } else {
        if (empty($nova_senha)) {
            $sql_update = "UPDATE cliente SET nome = '$novo_nome', email = '$novo_email', telefone = '$novo_telefone' WHERE id_cliente = $id_cliente";
        } else {
            $senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);
            $sql_update = "UPDATE cliente SET nome = '$novo_nome', email = '$novo_email', senha = '$senha_hash', telefone = '$novo_telefone' WHERE id_cliente = $id_cliente";
        }

        if ($conn->query($sql_update) === TRUE) {
            $mensagem = "Dados atualizados com sucesso!";
            $result = $conn->query("SELECT * FROM cliente WHERE id_cliente = $id_cliente");
            $cliente = $result->fetch_assoc();
        } else {
            $mensagem = "Erro ao atualizar: " . $conn->error;
        }
    }
}

if (isset($_POST['excluir'])) {
    $conn->query("DELETE FROM cliente WHERE id_cliente = $id_cliente");
    session_destroy();
    header("Location: ../login.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil - Cliente</title>
    <link rel="stylesheet" href="../css/perfil_vendedor.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            // Formata o telefone automaticamente
            $("#telefone").on("input", function() {
                var telefone = $(this).val().replace(/\D/g, ""); // Remove tudo que não for número
                if (telefone.length <= 2) {
                    telefone = "(" + telefone;
                } else if (telefone.length <= 7) {
                    telefone = "(" + telefone.slice(0, 2) + ") " + telefone.slice(2);
                } else {
                    telefone = "(" + telefone.slice(0, 2) + ") " + telefone.slice(2, 7) + "-" + telefone.slice(7, 11);
                }
                $(this).val(telefone);
            });
        });
    </script>
</head>
<body>
    <div class="perfil-container">
        <h1>Editar Perfil</h1>

        <?php if ($mensagem): ?>
            <div class="mensagem <?php echo strpos($mensagem, 'Erro') === 0 ? 'erro' : 'sucesso'; ?>">
                <?php echo $mensagem; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" value="<?php echo htmlspecialchars($cliente['nome']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($cliente['email']); ?>" required>

            <label for="telefone">Telefone:</label>
            <input type="text" name="telefone" id="telefone" value="<?php echo htmlspecialchars($telefone_formatado); ?>" required>

            <label for="senha">Nova Senha (deixe em branco para manter):</label>
            <input type="password" name="senha" placeholder="Nova senha (opcional)">

            <button type="submit">Atualizar</button>
        </form>

        <form method="POST">
            <button type="submit" name="excluir" class="excluir">Excluir Conta</button>
        </form>

        <form action="site.php" method="GET">
            <button type="submit">Voltar para o Menu</button>
        </form>
    </div>
</body>
</html>
