<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['id_cliente']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: painelAdmin.php?erro=acesso");
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: painelAdmin.php?erro=sem_id");
    exit();
}

$id_cliente = (int)$_GET['id'];

// Opcional: Excluir relacionamentos do cliente em outras tabelas antes
// Ex: vendas, pedidos, etc., se houver integridade referencial

$stmt = $conn->prepare("DELETE FROM cliente WHERE id_cliente = ?");
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$stmt->close();

$conn->close();

header("Location: painelAdmin.php?cliente_excluido=1");
exit();
