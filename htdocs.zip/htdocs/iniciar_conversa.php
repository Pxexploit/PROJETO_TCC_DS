<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'cliente') {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Apenas clientes podem iniciar conversas']);
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_login";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

header('Content-Type: application/json');

$produto_id = intval($_POST['produto_id'] ?? 0);
$cliente_id = $_SESSION['usuario_id'];

if ($produto_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Produto inválido']);
    exit();
}

// Buscar dados do produto e vendedor
$sql_produto = "SELECT p.*, v.id_vendedor, v.nome as vendedor_nome, l.nome as loja_nome
                FROM produto p
                JOIN loja l ON p.id_loja = l.id_loja
                JOIN vendedor v ON l.id_loja = v.id_loja
                WHERE p.id_produto = ?";
$stmt_produto = $conn->prepare($sql_produto);
$stmt_produto->bind_param("i", $produto_id);
$stmt_produto->execute();
$produto = $stmt_produto->get_result()->fetch_assoc();

if (!$produto) {
    echo json_encode(['success' => false, 'message' => 'Produto não encontrado']);
    exit();
}

$vendedor_id = $produto['id_vendedor'];

// Verificar se já existe uma conversa para este produto
$sql_verificar = "SELECT id_conversa FROM conversas WHERE id_cliente = ? AND id_vendedor = ? AND id_produto = ?";
$stmt_verificar = $conn->prepare($sql_verificar);
$stmt_verificar->bind_param("iii", $cliente_id, $vendedor_id, $produto_id);
$stmt_verificar->execute();
$conversa_existente = $stmt_verificar->get_result()->fetch_assoc();

if ($conversa_existente) {
    // Conversa já existe, redirecionar para ela
    echo json_encode([
        'success' => true, 
        'conversa_id' => $conversa_existente['id_conversa'],
        'message' => 'Conversa já existe'
    ]);
    exit();
}

// Criar nova conversa
$sql_conversa = "INSERT INTO conversas (id_cliente, id_vendedor, id_produto) VALUES (?, ?, ?)";
$stmt_conversa = $conn->prepare($sql_conversa);
$stmt_conversa->bind_param("iii", $cliente_id, $vendedor_id, $produto_id);

if ($stmt_conversa->execute()) {
    $conversa_id = $stmt_conversa->insert_id;
    
    // Enviar mensagem inicial automática
    $mensagem_inicial = "Olá! Tenho interesse no produto \"" . $produto['nome'] . "\". Poderia me dar mais informações?";
    $sql_mensagem = "INSERT INTO mensagens (id_conversa, id_remetente, tipo_remetente, mensagem) VALUES (?, ?, 'cliente', ?)";
    $stmt_mensagem = $conn->prepare($sql_mensagem);
    $stmt_mensagem->bind_param("iis", $conversa_id, $cliente_id, $mensagem_inicial);
    $stmt_mensagem->execute();
    
    echo json_encode([
        'success' => true, 
        'conversa_id' => $conversa_id,
        'message' => 'Conversa iniciada com sucesso'
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao criar conversa: ' . $conn->error]);
}

$conn->close();
?>
