<?php
session_start();

if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['usuario_tipo'], ['cliente', 'vendedor'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_login";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

header('Content-Type: application/json');

$mensagem_id = intval($_POST['mensagem_id'] ?? 0);
$usuario_id = $_SESSION['usuario_id'];
$usuario_tipo = $_SESSION['usuario_tipo'];

if ($mensagem_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Mensagem inválida']);
    exit();
}

// Verificar se a mensagem existe e o usuário tem permissão para excluí-la
$sql_verificar = "SELECT m.*, c.id_cliente, c.id_vendedor 
                  FROM mensagens m 
                  JOIN conversas c ON m.id_conversa = c.id_conversa 
                  WHERE m.id_mensagem = ? AND m.id_remetente = ? AND m.tipo_remetente = ?";
$stmt_verificar = $conn->prepare($sql_verificar);
$stmt_verificar->bind_param("iis", $mensagem_id, $usuario_id, $usuario_tipo);
$stmt_verificar->execute();
$mensagem = $stmt_verificar->get_result()->fetch_assoc();

if (!$mensagem) {
    echo json_encode(['success' => false, 'message' => 'Mensagem não encontrada ou sem permissão']);
    exit();
}

// Excluir arquivo físico se existir
if ($mensagem['arquivo_caminho'] && file_exists($mensagem['arquivo_caminho'])) {
    unlink($mensagem['arquivo_caminho']);
}

// Excluir mensagem do banco
$sql_excluir = "DELETE FROM mensagens WHERE id_mensagem = ?";
$stmt_excluir = $conn->prepare($sql_excluir);
$stmt_excluir->bind_param("i", $mensagem_id);

if ($stmt_excluir->execute()) {
    // Verificar se ainda há mensagens na conversa
    $sql_contar = "SELECT COUNT(*) as total FROM mensagens WHERE id_conversa = ?";
    $stmt_contar = $conn->prepare($sql_contar);
    $stmt_contar->bind_param("i", $mensagem['id_conversa']);
    $stmt_contar->execute();
    $resultado = $stmt_contar->get_result()->fetch_assoc();
    
    // Se não há mais mensagens, excluir a conversa também
    if ($resultado['total'] == 0) {
        $sql_excluir_conversa = "DELETE FROM conversas WHERE id_conversa = ?";
        $stmt_excluir_conversa = $conn->prepare($sql_excluir_conversa);
        $stmt_excluir_conversa->bind_param("i", $mensagem['id_conversa']);
        $stmt_excluir_conversa->execute();
    }
    
    echo json_encode(['success' => true, 'message' => 'Mensagem excluída com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao excluir mensagem: ' . $conn->error]);
}

$conn->close();
?>
