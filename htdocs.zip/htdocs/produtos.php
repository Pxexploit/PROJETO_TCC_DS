<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'admin') {
    echo "Acesso negado.";
    exit();
}

$result = $conn->query("SELECT * FROM produto");

echo "<h2>Lista de Produtos</h2>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Nome</th><th>Preço</th><th>Ações</th></tr>";

while ($p = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$p['id_produto']}</td>
        <td>{$p['nome_produto']}</td>
        <td>R$ " . number_format($p['preco'], 2, ',', '.') . "</td>
        <td>
            <a href='editar_produto.php?id={$p['id_produto']}'>Editar</a> |
            <a href='excluir_produto.php?id={$p['id_produto']}' onclick=\"return confirm('Deseja realmente excluir?')\">Excluir</a>
        </td>
    </tr>";
}
echo "</table>";
