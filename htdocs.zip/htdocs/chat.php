<?php
session_start();

if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['usuario_tipo'], ['cliente', 'vendedor'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sistema_login";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$usuario_id = $_SESSION['usuario_id'];
$usuario_tipo = $_SESSION['usuario_tipo'];
$conversa_id = isset($_GET['conversa']) ? intval($_GET['conversa']) : 0;
$produto_id = isset($_GET['produto']) ? intval($_GET['produto']) : 0;

// Buscar conversas do usuário
if ($usuario_tipo === 'cliente') {
    $sql_conversas = "SELECT c.*, p.nome as produto_nome, p.imagem as produto_imagem, 
                      v.nome as vendedor_nome, l.nome as loja_nome,
                      (SELECT COUNT(*) FROM mensagens m WHERE m.id_conversa = c.id_conversa AND m.tipo_remetente = 'vendedor' AND m.lida = 0) as nao_lidas
                      FROM conversas c
                      JOIN produto p ON c.id_produto = p.id_produto
                      JOIN vendedor v ON c.id_vendedor = v.id_vendedor
                      JOIN loja l ON v.id_loja = l.id_loja
                      WHERE c.id_cliente = ? AND c.status = 'ativa'
                      ORDER BY c.ultima_mensagem DESC";
    $stmt_conversas = $conn->prepare($sql_conversas);
    $stmt_conversas->bind_param("i", $usuario_id);
} else {
    $sql_conversas = "SELECT c.*, p.nome as produto_nome, p.imagem as produto_imagem, 
                      cl.nome as cliente_nome,
                      (SELECT COUNT(*) FROM mensagens m WHERE m.id_conversa = c.id_conversa AND m.tipo_remetente = 'cliente' AND m.lida = 0) as nao_lidas
                      FROM conversas c
                      JOIN produto p ON c.id_produto = p.id_produto
                      JOIN cliente cl ON c.id_cliente = cl.id_cliente
                      WHERE c.id_vendedor = ? AND c.status = 'ativa'
                      ORDER BY c.ultima_mensagem DESC";
    $stmt_conversas = $conn->prepare($sql_conversas);
    $stmt_conversas->bind_param("i", $usuario_id);
}

$stmt_conversas->execute();
$conversas = $stmt_conversas->get_result();

// Buscar mensagens da conversa atual
$mensagens = [];
$conversa_atual = null;
if ($conversa_id > 0) {
    // Buscar dados da conversa
    $sql_conversa = "SELECT c.*, p.nome as produto_nome, p.imagem as produto_imagem, p.preco as produto_preco,
                     v.nome as vendedor_nome, l.nome as loja_nome, cl.nome as cliente_nome
                     FROM conversas c
                     JOIN produto p ON c.id_produto = p.id_produto
                     JOIN vendedor v ON c.id_vendedor = v.id_vendedor
                     JOIN loja l ON v.id_loja = l.id_loja
                     JOIN cliente cl ON c.id_cliente = cl.id_cliente
                     WHERE c.id_conversa = ?";
    $stmt_conversa = $conn->prepare($sql_conversa);
    $stmt_conversa->bind_param("i", $conversa_id);
    $stmt_conversa->execute();
    $conversa_atual = $stmt_conversa->get_result()->fetch_assoc();
    
    if ($conversa_atual) {
        // Buscar mensagens
        $sql_mensagens = "SELECT m.*, 
                         CASE 
                             WHEN m.tipo_remetente = 'cliente' THEN cl.nome
                             ELSE v.nome
                         END as remetente_nome
                         FROM mensagens m
                         LEFT JOIN cliente cl ON m.tipo_remetente = 'cliente' AND m.id_remetente = cl.id_cliente
                         LEFT JOIN vendedor v ON m.tipo_remetente = 'vendedor' AND m.id_remetente = v.id_vendedor
                         WHERE m.id_conversa = ?
                         ORDER BY m.data_envio ASC";
        $stmt_mensagens = $conn->prepare($sql_mensagens);
        $stmt_mensagens->bind_param("i", $conversa_id);
        $stmt_mensagens->execute();
        $mensagens = $stmt_mensagens->get_result();
        
        // Marcar mensagens como lidas
        $sql_marcar_lidas = "UPDATE mensagens SET lida = 1 WHERE id_conversa = ? AND tipo_remetente != ?";
        $stmt_marcar = $conn->prepare($sql_marcar_lidas);
        $tipo_oposto = $usuario_tipo === 'cliente' ? 'vendedor' : 'cliente';
        $stmt_marcar->bind_param("is", $conversa_id, $tipo_oposto);
        $stmt_marcar->execute();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Chat - TaquaMarket</title>
    <link rel="stylesheet" href="css/chat.css">
    <link rel="stylesheet" href="css/telaproduto.css">
</head>
<body>
    <div class="chat-container">
        <!-- Sidebar com lista de conversas -->
        <div class="chat-sidebar">
            <div class="sidebar-header">
                <h3>💬 Mensagens</h3>
                <a href="telaprodutos.php" class="btn-voltar">← Voltar</a>
            </div>
            
            <div class="conversas-list">
                <?php if ($conversas->num_rows > 0): ?>
                    <?php while ($conversa = $conversas->fetch_assoc()): ?>
                        <div class="conversa-item <?php echo $conversa['id_conversa'] == $conversa_id ? 'active' : ''; ?>" 
                             data-conversa-id="<?php echo $conversa['id_conversa']; ?>">
                            <div class="conversa-content" onclick="abrirConversa(<?php echo $conversa['id_conversa']; ?>)">
                                <div class="conversa-avatar">
                                    <img src="uploads/<?php echo htmlspecialchars($conversa['produto_imagem']); ?>" 
                                         alt="<?php echo htmlspecialchars($conversa['produto_nome']); ?>">
                                </div>
                                <div class="conversa-info">
                                    <div class="conversa-nome">
                                        <?php 
                                        if ($usuario_tipo === 'cliente') {
                                            echo htmlspecialchars($conversa['vendedor_nome'] . ' - ' . $conversa['loja_nome']);
                                        } else {
                                            echo htmlspecialchars($conversa['cliente_nome']);
                                        }
                                        ?>
                                    </div>
                                    <div class="conversa-produto"><?php echo htmlspecialchars($conversa['produto_nome']); ?></div>
                                    <div class="conversa-tempo"><?php echo date('d/m H:i', strtotime($conversa['ultima_mensagem'])); ?></div>
                                </div>
                                <?php if ($conversa['nao_lidas'] > 0): ?>
                                    <div class="nao-lidas"><?php echo $conversa['nao_lidas']; ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="conversa-options">
                                <button class="conversa-menu-btn" onclick="event.stopPropagation(); toggleConversaItemMenu(<?php echo $conversa['id_conversa']; ?>)">⋮</button>
                                <div class="conversa-item-menu" id="conversa-menu-<?php echo $conversa['id_conversa']; ?>">
                                    <button onclick="excluirConversaFromList(<?php echo $conversa['id_conversa']; ?>)" class="menu-item delete">
                                        🗑️ Excluir Conversa
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="sem-conversas">
                        <p>Nenhuma conversa encontrada</p>
                        <a href="telaprodutos.php">Ver produtos</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Área principal do chat -->
        <div class="chat-main">
            <?php if ($conversa_atual): ?>
                <!-- Header da conversa -->
                <div class="chat-header">
                    <div class="chat-produto-info">
                        <img src="uploads/<?php echo htmlspecialchars($conversa_atual['produto_imagem']); ?>" 
                             alt="<?php echo htmlspecialchars($conversa_atual['produto_nome']); ?>">
                        <div class="produto-detalhes">
                            <h4><?php echo htmlspecialchars($conversa_atual['produto_nome']); ?></h4>
                            <p>R$ <?php echo number_format($conversa_atual['produto_preco'], 2, ',', '.'); ?></p>
                        </div>
                    </div>
                    <div class="chat-contato-info">
                        <?php if ($usuario_tipo === 'cliente'): ?>
                            <p><strong><?php echo htmlspecialchars($conversa_atual['vendedor_nome']); ?></strong></p>
                            <p><?php echo htmlspecialchars($conversa_atual['loja_nome']); ?></p>
                        <?php else: ?>
                            <p><strong><?php echo htmlspecialchars($conversa_atual['cliente_nome']); ?></strong></p>
                        <?php endif; ?>
                    </div>
                    <div class="chat-options">
                        <button class="chat-menu-btn" onclick="toggleConversaMenu()">⋮</button>
                        <div class="chat-menu" id="chat-menu">
                            <button onclick="excluirConversa()" class="menu-item delete">
                                🗑️ Excluir Conversa
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Área de mensagens -->
                <div class="chat-messages" id="chat-messages">
                    <?php if ($mensagens->num_rows > 0): ?>
                        <?php while ($mensagem = $mensagens->fetch_assoc()): ?>
                            <div class="message <?php echo $mensagem['tipo_remetente'] === $usuario_tipo ? 'own' : 'other'; ?>" 
                                 data-mensagem-id="<?php echo $mensagem['id_mensagem']; ?>">
                                <div class="message-content">
                                    <?php if ($mensagem['tipo_mensagem'] === 'texto'): ?>
                                        <p><?php echo nl2br(htmlspecialchars($mensagem['mensagem'])); ?></p>
                                    <?php elseif ($mensagem['tipo_mensagem'] === 'imagem'): ?>
                                        <img src="<?php echo htmlspecialchars($mensagem['arquivo_caminho']); ?>" 
                                             alt="Imagem" class="message-image">
                                    <?php elseif ($mensagem['tipo_mensagem'] === 'video'): ?>
                                        <video controls class="message-video">
                                            <source src="<?php echo htmlspecialchars($mensagem['arquivo_caminho']); ?>" type="video/mp4">
                                        </video>
                                    <?php else: ?>
                                        <a href="<?php echo htmlspecialchars($mensagem['arquivo_caminho']); ?>" 
                                           download="<?php echo htmlspecialchars($mensagem['arquivo_nome']); ?>" 
                                           class="message-file">
                                            📎 <?php echo htmlspecialchars($mensagem['arquivo_nome']); ?>
                                        </a>
                                    <?php endif; ?>
                                    <div class="message-footer">
                                        <div class="message-time">
                                            <?php echo date('H:i', strtotime($mensagem['data_envio'])); ?>
                                        </div>
                                        <?php if ($mensagem['tipo_remetente'] === $usuario_tipo): ?>
                                            <button class="message-menu-btn" onclick="toggleMessageMenu(<?php echo $mensagem['id_mensagem']; ?>)">⋮</button>
                                            <div class="message-menu" id="message-menu-<?php echo $mensagem['id_mensagem']; ?>">
                                                <button onclick="excluirMensagem(<?php echo $mensagem['id_mensagem']; ?>)" class="menu-item delete">
                                                    🗑️ Excluir
                                                </button>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="no-messages">
                            <p>Nenhuma mensagem ainda. Seja o primeiro a enviar!</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Área de envio de mensagem -->
                <div class="chat-input">
                    <form id="message-form" enctype="multipart/form-data">
                        <input type="hidden" name="conversa_id" value="<?php echo $conversa_id; ?>">
                        <div class="input-group">
                            <button type="button" class="btn-attach" onclick="document.getElementById('file-input').click()">
                                📎
                            </button>
                            <input type="file" id="file-input" name="arquivo" accept="image/*,video/*,.pdf,.doc,.docx" style="display: none;">
                            <input type="text" name="mensagem" placeholder="Digite sua mensagem..." class="message-input" required>
                            <button type="submit" class="btn-send">Enviar</button>
                        </div>
                    </form>
                </div>
            <?php else: ?>
                <div class="no-conversation">
                    <div class="no-conversation-content">
                        <h3>💬 Selecione uma conversa</h3>
                        <p>Escolha uma conversa na barra lateral para começar a conversar</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function abrirConversa(conversaId) {
            window.location.href = 'chat.php?conversa=' + conversaId;
        }

        // Auto-scroll para a última mensagem
        function scrollToBottom() {
            const chatMessages = document.getElementById('chat-messages');
            if (chatMessages) {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        }

        // Enviar mensagem via AJAX
        document.getElementById('message-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const xhr = new XMLHttpRequest();
            
            xhr.open('POST', 'enviar_mensagem.php', true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Erro ao enviar mensagem: ' + response.message);
                    }
                }
            };
            
            xhr.send(formData);
        });

        // Auto-refresh das mensagens a cada 5 segundos
        setInterval(function() {
            if (<?php echo $conversa_id; ?> > 0) {
                const xhr = new XMLHttpRequest();
                xhr.open('GET', 'buscar_mensagens.php?conversa=<?php echo $conversa_id; ?>', true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.new_messages) {
                            location.reload();
                        }
                    }
                };
                xhr.send();
            }
        }, 5000);

        // Funções para menus de três pontos
        function toggleConversaMenu() {
            const menu = document.getElementById('chat-menu');
            menu.classList.toggle('show');
            
            // Fechar outros menus
            document.querySelectorAll('.message-menu, .conversa-item-menu').forEach(m => m.classList.remove('show'));
        }

        function toggleMessageMenu(mensagemId) {
            const menu = document.getElementById('message-menu-' + mensagemId);
            menu.classList.toggle('show');
            
            // Fechar outros menus
            document.querySelectorAll('.chat-menu, .conversa-item-menu, .message-menu').forEach(m => {
                if (m.id !== 'message-menu-' + mensagemId) {
                    m.classList.remove('show');
                }
            });
        }

        function toggleConversaItemMenu(conversaId) {
            const menu = document.getElementById('conversa-menu-' + conversaId);
            menu.classList.toggle('show');
            
            // Fechar outros menus
            document.querySelectorAll('.chat-menu, .message-menu, .conversa-item-menu').forEach(m => {
                if (m.id !== 'conversa-menu-' + conversaId) {
                    m.classList.remove('show');
                }
            });
        }

        function excluirMensagem(mensagemId) {
            if (confirm('Tem certeza que deseja excluir esta mensagem?')) {
                const formData = new FormData();
                formData.append('mensagem_id', mensagemId);
                
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'excluir_mensagem.php', true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            location.reload();
                        } else {
                            alert('Erro: ' + response.message);
                        }
                    }
                };
                xhr.send(formData);
            }
        }

        function excluirConversa() {
            if (confirm('Tem certeza que deseja excluir esta conversa? Todas as mensagens serão perdidas.')) {
                const formData = new FormData();
                formData.append('conversa_id', <?php echo $conversa_id; ?>);
                
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'excluir_conversa.php', true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            window.location.href = 'chat.php';
                        } else {
                            alert('Erro: ' + response.message);
                        }
                    }
                };
                xhr.send(formData);
            }
        }

        function excluirConversaFromList(conversaId) {
            if (confirm('Tem certeza que deseja excluir esta conversa? Todas as mensagens serão perdidas.')) {
                const formData = new FormData();
                formData.append('conversa_id', conversaId);
                
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'excluir_conversa.php', true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            // Remover o item da lista
                            const conversaItem = document.querySelector('[data-conversa-id="' + conversaId + '"]');
                            if (conversaItem) {
                                conversaItem.remove();
                            }
                            
                            // Se era a conversa ativa, redirecionar
                            if (conversaId == <?php echo $conversa_id; ?>) {
                                window.location.href = 'chat.php';
                            }
                        } else {
                            alert('Erro: ' + response.message);
                        }
                    }
                };
                xhr.send(formData);
            }
        }

        // Fechar menus ao clicar fora
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.chat-menu, .message-menu, .conversa-item-menu, .chat-menu-btn, .message-menu-btn, .conversa-menu-btn')) {
                document.querySelectorAll('.chat-menu, .message-menu, .conversa-item-menu').forEach(menu => {
                    menu.classList.remove('show');
                });
            }
        });

        // Scroll inicial
        document.addEventListener('DOMContentLoaded', function() {
            scrollToBottom();
        });
    </script>
</body>
</html>

<?php $conn->close(); ?>
