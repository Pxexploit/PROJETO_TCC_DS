-- Sistema de Mensagens Internas tabelas de rascunho chat
-- Criar tabela para conversas
CREATE TABLE IF NOT EXISTS conversas (
    id_conversa INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_vendedor INT NOT NULL,
    id_produto INT NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ultima_mensagem TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status ENUM('ativa', 'arquivada') DEFAULT 'ativa',
    FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente) ON DELETE CASCADE,
    FOREIGN KEY (id_vendedor) REFERENCES vendedor(id_vendedor) ON DELETE CASCADE,
    FOREIGN KEY (id_produto) REFERENCES produto(id_produto) ON DELETE CASCADE,
    UNIQUE KEY unique_conversa (id_cliente, id_vendedor, id_produto)
);

-- Criar tabela para mensagens
CREATE TABLE IF NOT EXISTS mensagens (
    id_mensagem INT AUTO_INCREMENT PRIMARY KEY,
    id_conversa INT NOT NULL,
    id_remetente INT NOT NULL,
    tipo_remetente ENUM('cliente', 'vendedor') NOT NULL,
    mensagem TEXT,
    tipo_mensagem ENUM('texto', 'imagem', 'video', 'arquivo') DEFAULT 'texto',
    arquivo_nome VARCHAR(255),
    arquivo_caminho VARCHAR(500),
    arquivo_tamanho INT,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lida BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (id_conversa) REFERENCES conversas(id_conversa) ON DELETE CASCADE
);

-- Criar tabela para status de leitura
CREATE TABLE IF NOT EXISTS mensagens_lidas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_mensagem INT NOT NULL,
    id_usuario INT NOT NULL,
    tipo_usuario ENUM('cliente', 'vendedor') NOT NULL,
    data_leitura TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_mensagem) REFERENCES mensagens(id_mensagem) ON DELETE CASCADE
);

-- Índices para melhor performance
CREATE INDEX idx_conversas_cliente ON conversas(id_cliente);
CREATE INDEX idx_conversas_vendedor ON conversas(id_vendedor);
CREATE INDEX idx_conversas_produto ON conversas(id_produto);
CREATE INDEX idx_mensagens_conversa ON mensagens(id_conversa);
CREATE INDEX idx_mensagens_data ON mensagens(data_envio);
CREATE INDEX idx_mensagens_lidas_usuario ON mensagens_lidas(id_usuario, tipo_usuario);
