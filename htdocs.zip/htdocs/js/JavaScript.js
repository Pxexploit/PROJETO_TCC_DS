document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');
    
    form.addEventListener('submit', (e) => {
        let valid = true;
    
        const inputs = form.querySelectorAll('input');
        inputs.forEach(input => {
            if (input.value === '') {
                valid = false;
                input.style.borderColor = 'red';
            } else {
                input.style.borderColor = '';
            }
        });
        
        if (!valid) {
            e.preventDefault();
            alert('Por favor, preencha todos os campos.');
        }
    });
});
