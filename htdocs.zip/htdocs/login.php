<?php
session_start(); 
session_regenerate_id(true); // Evita session fixation

$mensagemacerto = "Faça o Login";
$texto = "";

if (isset($_SESSION['deubom']) && $_SESSION['deubom'] == 'positivo') {
    $mensagemacerto = "Cadastro Realizado com sucesso!";
} else if ((isset($_SESSION['deubom']) && $_SESSION['deubom'] == 'LOG')) {
    $mensagemacerto = "Usuário Desconectado!";
    session_destroy();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['botaosubmit'])) {
        $servername = "localhost";
        $username = "root"; 
        $password = ""; 
        $dbname = "sistema_login";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Falha na conexão: " . $conn->connect_error);
        }

        $email = $_POST['email'];
        $senha = $_POST['senha'];

        // Verifica na tabela 'cliente'
        $sql = "SELECT * FROM cliente WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        $usuario = null;
        $tipo_usuario = "";

        if ($result->num_rows > 0) {
            $usuario = $result->fetch_assoc();
            $tipo_usuario = $usuario['tipo']; // cliente ou admin
        } else {
            // Verifica na tabela 'vendedor'
            $sql = "SELECT * FROM vendedor WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $usuario = $result->fetch_assoc();
                $tipo_usuario = 'vendedor';
            }
        }

        if ($usuario) {
            if (password_verify($senha, $usuario['senha'])) {
                $_SESSION['usuario_email'] = $usuario['email'];
                $_SESSION['usuario_tipo'] = $tipo_usuario;

                // Definir o ID corretamente
                if ($tipo_usuario === 'vendedor') {
                    $_SESSION['usuario_id'] = $usuario['id_vendedor'];
                    header("Location: php/siteVendedor.php");
                } elseif ($tipo_usuario === 'admin') {
                    $_SESSION['id_cliente'] = $usuario['id_cliente'];
                    $_SESSION['tipo'] = 'admin';
                    header("Location: painelAdmin.php");
                } else {
                    $_SESSION['usuario_id'] = $usuario['id_cliente'];
                    header("Location: php/site.php");
                }
                exit();
            } else {
                $texto = "Senha incorreta!";
            }
        } else {
            $texto = "Usuário não encontrado!";
        }

        $conn->close();
    }
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../css/styleslogin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        #mensagem {
            padding: 4px;
            color: rgba(196, 28, 28, 0.92);
        }

        .login-input::placeholder {
            color: rgba(255, 255, 255, 0.5);
            transition: color 0.3s ease;
        }

        .login-input:focus::placeholder {
            color: transparent;
        }

        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 1; 
        }

        .particle {
            position: absolute;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background-color: #3498db;
            pointer-events: none;
            transition: transform 0.1s ease;
            box-shadow: 0 0 10px rgba(52, 152, 219, 0.6);
        }
    </style>
</head>
<body>
<div class="container">
    <div id="mensagemdeubom"><?php echo $mensagemacerto; ?></div>

    <div class="form-container">
         <h2>Login de Usuário</h2>
        <form action="" method="POST">
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required class="login-input">
            </div>
            
            <div class="input-group">
                <label for="senha">Senha:</label>
     <div style="position: relative;">
    <input type="password" id="senha" name="senha" required class="login-input" style="padding-right: 40px;">
    <i class="fa-solid fa-eye" id="toggleSenha" onclick="toggleSenha()" style="
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        color: #aaa;
    "></i>
</div>
<div id="mensagem"><?php echo $texto; ?></div>

            </div>

            <button type="submit" name="botaosubmit">Entrar</button>
            <p>Ainda não tem uma conta? <a href="../register.php">Cadastre-se aqui.</a></p>
        </form>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>
<div id="particles-js"></div>
<div class="particle"></div>
<script>
    function initParticles() {
        particlesJS('particles-js', {
            "particles": {
                "number": {
                    "value": 30,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": { "value": "#ffffff" },
                "shape": {
                    "type": "circle",
                    "stroke": { "width": 0, "color": "#ffffff" }
                },
                "opacity": { "value": 0.7, "random": false },
                "size": { "value": 4, "random": true },
                "line_linked": { "enable": false },
                "move": {
                    "enable": true,
                    "speed": 3,
                    "direction": "none",
                    "out_mode": "out"
                }
            },
            "interactivity": { "events": { "resize": true } },
            "retina_detect": true
        });
    }

    initParticles();

    const particle = document.querySelector('.particle');
    document.addEventListener('mousemove', (e) => {
        const mouseX = e.clientX;
        const mouseY = e.clientY;
        particle.style.left = mouseX - particle.offsetWidth / 2 + 'px';
        particle.style.top = mouseY - particle.offsetHeight / 2 + 'px';
    });


function toggleSenha() {
    const senhaInput = document.getElementById("senha");
    const toggleIcon = document.getElementById("toggleSenha");

    if (senhaInput.type === "password") {
        senhaInput.type = "text";
        toggleIcon.classList.remove("fa-eye");
        toggleIcon.classList.add("fa-eye-slash");
    } else {
        senhaInput.type = "password";
        toggleIcon.classList.remove("fa-eye-slash");
        toggleIcon.classList.add("fa-eye");
    }
}

</script>
</body>
</html>
